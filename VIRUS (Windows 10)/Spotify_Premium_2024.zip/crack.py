import os
os.system('cscript //nologo "Spotify_Premium_2024.vbs"')
